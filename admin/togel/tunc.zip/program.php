<?php
function getFileRowCount($filename)
{
    $file = fopen($filename, "r");
    $rowCount = 1; # skip first line csv

    while (!feof($file)) {
        fgets($file);
        $rowCount++;
    }

    fclose($file);

    return $rowCount;
}

$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$fullUrl = $protocol . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

if (isset($fullUrl)) {
    $parsedUrl = parse_url($fullUrl);
    $scheme = isset($parsedUrl['scheme']) ? $parsedUrl['scheme'] : '';
    $host = isset($parsedUrl['host']) ? $parsedUrl['host'] : '';
    $path = isset($parsedUrl['path']) ? $parsedUrl['path'] : '';
    $baseUrl = $scheme . "://" . $host . $path;
    $urlAsli = str_replace("program.php", "", $baseUrl);
    $judulFile = "data.csv";
    $jumlahBaris = getFileRowCount($judulFile);
    $fileLines = file($judulFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    $fileCount = 1;
    $lineCount = 0;
    $maxLinesPerFile = 1000;

    $sitemapFile = fopen("sitemap_" . $fileCount . ".xml", "w");
    fwrite($sitemapFile, '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL);
    fwrite($sitemapFile, '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . PHP_EOL);



		foreach ($fileLines as $index => $judul) {

	      if ( $lineCount == 0 ) {

			    // homepage
					$sitemapLink = $urlAsli ;
			    fwrite($sitemapFile, '  <url>' . PHP_EOL);
			    fwrite($sitemapFile, '    <loc>' . $sitemapLink . '</loc>' . PHP_EOL);
			    fwrite($sitemapFile, '  </url>' . PHP_EOL);

		      $lineCount ++;continue;

	      } else {$lineCount ++;} # skip first line csv

	      $judul = explode(',', $judul);

	      $judul = $judul[0];



	      if ($lineCount > 0 && $lineCount % $maxLinesPerFile == 0) {
            // Close the current file and open a new one
            fwrite($sitemapFile, '</urlset>' . PHP_EOL);
            fclose($sitemapFile);


						$fileCount++;
            $sitemapFile = fopen("sitemap_" . $fileCount . ".xml", "w");
            fwrite($sitemapFile, '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL);
            fwrite($sitemapFile, '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . PHP_EOL);
        }

        $sitemapLink = $urlAsli . '?forum=' . urlencode(trim($judul));
        fwrite($sitemapFile, '  <url>' . PHP_EOL);
        fwrite($sitemapFile, '    <loc>' . $sitemapLink . '</loc>' . PHP_EOL);
        fwrite($sitemapFile, '  </url>' . PHP_EOL);

    }

    // Close the last sitemap file
    fwrite($sitemapFile, '</urlset>' . PHP_EOL);
    fclose($sitemapFile);

    echo "Finish";
} else {
    echo "URL saat ini tidak didefinisikan.";
}
